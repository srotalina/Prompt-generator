// main.jsx
//
// CONCEPT: Provider placement.
// QueryClientProvider wraps the whole app ONCE, at the root. This is what
// makes the React Query cache global and shared — any component,
// anywhere in the tree, calling usePrompts() gets the SAME cached data,
// without prop-drilling it down manually. This is the "context provider
// at the root" pattern you'll see repeated for theme, auth, i18n — any
// cross-cutting concern the whole tree needs access to.

import React from "react";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import App from "./App";
import "./index.css";

const queryClient = new QueryClient();

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </React.StrictMode>
);
