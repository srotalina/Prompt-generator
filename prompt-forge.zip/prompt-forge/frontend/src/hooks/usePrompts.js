// hooks/usePrompts.js
//
// CONCEPT: Server state vs. client state (this is the Module 5 topic —
// State and Data Flow at Scale — showing up concretely).
//
// The list of saved prompts is SERVER state: it lives in the backend,
// can go stale, can be wrong if two tabs are open, and needs re-fetching,
// caching, and loading/error states. This is NOT the same category of
// thing as, say, "is the modal open" — that's CLIENT state (useState is
// fine for that; you'll see it in PromptGenerator.jsx for the streaming
// text buffer).
//
// Reaching for Redux/Context to hold "the prompt list" would be solving
// the wrong problem — those tools manage CLIENT state well, but they
// don't give you caching, refetching, or request de-duplication for FREE.
// React Query does. This is exactly the kind of tool-to-problem mismatch
// an interviewer will probe: "why not just put this in Context?"

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchPrompts, createPrompt, removePrompt } from "../api/client";

const PROMPTS_KEY = ["prompts"];

export function usePrompts() {
  return useQuery({
    queryKey: PROMPTS_KEY,
    queryFn: fetchPrompts,
  });
}

export function useSavePrompt() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: createPrompt,
    // CONCEPT: Cache invalidation after a mutation.
    // After saving a new prompt, the cached list is stale. Instead of
    // manually splicing the new item into local state (easy to get wrong,
    // e.g. duplicate entries if the mutation retries), we just tell React
    // Query "this data is stale, refetch it." Simpler and more correct,
    // at the cost of one extra network round trip — a fine trade at this
    // scale.
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: PROMPTS_KEY });
    },
  });
}

export function useDeletePrompt() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: removePrompt,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: PROMPTS_KEY });
    },
  });
}
