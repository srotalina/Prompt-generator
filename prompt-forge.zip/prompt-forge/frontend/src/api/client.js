// api/client.js
//
// CONCEPT: A single API client module, not fetch() scattered across
// components. Every component that needs data calls a function FROM
// HERE — they never call fetch() directly. Why this matters: if the
// backend URL changes, or you add auth headers, or you switch from REST
// to something else, you edit ONE file instead of hunting through every
// component that happens to fetch something. This is the same "seam"
// idea as the repository pattern in the backend's db.js — same
// architectural instinct, applied at a different layer.

const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:4000/api";

export async function fetchPrompts() {
  const res = await fetch(`${BASE_URL}/prompts`);
  if (!res.ok) throw new Error("Failed to load prompts");
  return res.json();
}

export async function createPrompt({ title, body, category }) {
  const res = await fetch(`${BASE_URL}/prompts`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ title, body, category }),
  });
  if (!res.ok) throw new Error("Failed to save prompt");
  return res.json();
}

export async function removePrompt(id) {
  const res = await fetch(`${BASE_URL}/prompts/${id}`, { method: "DELETE" });
  if (!res.ok && res.status !== 204) throw new Error("Failed to delete prompt");
}

// CONCEPT: Streaming consumption on the frontend side.
// This isn't a normal async function returning one value — it's a
// generator-style callback API: "call onChunk every time text arrives."
// The component using this doesn't need to know HOW streaming works,
// just that it gets called repeatedly with new text. That's the same
// abstraction principle as the rest of this file, extended to a
// streaming use case.
export async function generatePromptStream({ topic, category }, onChunk) {
  const res = await fetch(`${BASE_URL}/generate`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ topic, category }),
  });

  if (!res.ok || !res.body) {
    throw new Error("Generation request failed");
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n\n");
    buffer = lines.pop(); // keep the last, possibly incomplete, chunk

    for (const line of lines) {
      if (!line.startsWith("data:")) continue;
      const payload = line.replace("data:", "").trim();
      if (payload === "[DONE]") return;
      try {
        const { text } = JSON.parse(payload);
        if (text) onChunk(text);
      } catch {
        // ignore malformed chunk
      }
    }
  }
}
