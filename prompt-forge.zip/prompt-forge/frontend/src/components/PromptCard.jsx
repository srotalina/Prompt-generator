// PromptCard.jsx
//
// CONCEPT: Presentational ("dumb") component.
// This component receives everything through props and calls a callback
// prop when the user acts — it has NO idea that React Query, fetch, or a
// backend even exist. That's deliberate: it means you could reuse this
// exact component with mock data in Storybook, in a test, or in a
// completely different data-fetching setup, with zero changes. The
// "smart" component (PromptLibrary) is the only one that knows about
// data-fetching; this one just renders what it's given.

export default function PromptCard({ prompt, onDelete }) {
  function handleCopy() {
    navigator.clipboard.writeText(prompt.body);
  }

  return (
    <article className="prompt-card">
      <header>
        <h3>{prompt.title}</h3>
        <span className="tag">{prompt.category}</span>
      </header>
      <p className="body">{prompt.body}</p>
      <footer>
        <button onClick={handleCopy}>Copy</button>
        <button onClick={() => onDelete(prompt.id)}>Delete</button>
      </footer>
    </article>
  );
}
