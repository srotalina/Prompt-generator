// PromptLibrary.jsx
//
// CONCEPT: Container/presentational split, in practice.
// This component is the ONLY one that calls usePrompts()/useDeletePrompt().
// It handles loading and error states, then hands clean data down to
// PromptCard, which knows nothing about where that data came from. If you
// ever added a search bar or pagination, this is the file that changes —
// PromptCard stays untouched.

import { usePrompts, useDeletePrompt } from "../hooks/usePrompts";
import PromptCard from "./PromptCard";

export default function PromptLibrary() {
  const { data: prompts, isLoading, isError } = usePrompts();
  const deleteMutation = useDeletePrompt();

  // CONCEPT: Handling all three real states of async data.
  // Every server-state read has (at minimum) three UI states: loading,
  // error, success. Skipping any of them is the #1 way "server state"
  // bugs make it to production — a blank screen on slow network, or a
  // silent failure on a dropped connection. React Query gives you these
  // flags for free; the discipline is actually rendering all three.
  if (isLoading) return <p>Loading your prompts…</p>;
  if (isError) return <p role="alert">Couldn't load your library. Refresh to retry.</p>;

  if (prompts.length === 0) {
    return <p className="empty-state">No saved prompts yet — generate one above.</p>;
  }

  return (
    <section className="library">
      <h2>Your prompt library</h2>
      <div className="grid">
        {prompts.map((p) => (
          <PromptCard key={p.id} prompt={p} onDelete={(id) => deleteMutation.mutate(id)} />
        ))}
      </div>
    </section>
  );
}
