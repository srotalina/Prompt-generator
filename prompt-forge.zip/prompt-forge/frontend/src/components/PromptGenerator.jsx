// PromptGenerator.jsx
//
// CONCEPT: This component owns CLIENT state only — topic input, category
// select, the streaming text buffer, and a status flag. None of that
// belongs in a global store; it's transient, local, and nobody else in
// the app needs it. That's the test for "does this need to be lifted
// up/globalized": if no sibling component needs it, it stays local.

import { useState } from "react";
import { generatePromptStream } from "../api/client";
import { useSavePrompt } from "../hooks/usePrompts";

const CATEGORIES = ["system-design", "debugging", "code-review", "interview-prep", "general"];

export default function PromptGenerator() {
  const [topic, setTopic] = useState("");
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [output, setOutput] = useState("");
  const [status, setStatus] = useState("idle"); // idle | streaming | done | error

  const saveMutation = useSavePrompt();

  // CONCEPT: Controlled inputs.
  // Every keystroke updates React state, and the input's `value` is
  // driven FROM that state. This is the standard React form pattern —
  // the DOM input never holds its own truth, React state does. It's more
  // verbose than an uncontrolled ref-based input, but it's what lets you
  // validate, disable, or transform input as the user types.
  async function handleGenerate(e) {
    e.preventDefault();
    if (!topic.trim()) return;

    setOutput("");
    setStatus("streaming");

    try {
      await generatePromptStream({ topic, category }, (chunk) => {
        // CONCEPT: Functional state updates.
        // We use the (prev => prev + chunk) form, not `setOutput(output + chunk)`.
        // Inside a streaming loop, `output` in the closure could be stale by
        // the time this runs — functional updates always operate on the
        // latest state, which matters a lot once updates arrive faster than
        // React re-renders.
        setOutput((prev) => prev + chunk);
      });
      setStatus("done");
    } catch (err) {
      console.error(err);
      setStatus("error");
    }
  }

  function handleSave() {
    saveMutation.mutate({ title: topic, body: output, category });
  }

  return (
    <section className="generator">
      <h2>Generate a prompt</h2>
      <form onSubmit={handleGenerate}>
        <label>
          Topic
          <input
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g. code review checklist for React PRs"
          />
        </label>

        <label>
          Category
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </label>

        <button type="submit" disabled={status === "streaming"}>
          {status === "streaming" ? "Generating…" : "Generate"}
        </button>
      </form>

      {/* CONCEPT: Deriving UI from state, not tracking booleans separately.
          We don't have isLoading/isError/isDone flags — `status` is a single
          source of truth and the JSX below just branches on it. Fewer
          independent booleans means fewer impossible states (e.g. loading
          AND error both true at once, which a flag-per-concern approach
          can accidentally allow). */}
      {status === "error" && <p role="alert">Something went wrong. Try again.</p>}

      {output && (
        <div className="output">
          <pre>{output}</pre>
          {status === "done" && (
            <button onClick={handleSave} disabled={saveMutation.isPending}>
              {saveMutation.isPending ? "Saving…" : "Save to library"}
            </button>
          )}
        </div>
      )}
    </section>
  );
}
