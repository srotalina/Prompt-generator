// App.jsx
//
// CONCEPT: Composition root.
// App.jsx doesn't know HOW generation or the library work internally —
// it just places two independent features next to each other. Neither
// component depends on the other directly; they're only connected
// through the shared React Query cache (generating + saving invalidates
// the same cache the library reads from). That indirection is
// deliberate — it means PromptGenerator and PromptLibrary could each be
// deleted or replaced without the other needing a single line changed.

import PromptGenerator from "./components/PromptGenerator";
import PromptLibrary from "./components/PromptLibrary";

export default function App() {
  return (
    <main className="app">
      <h1>Prompt Forge</h1>
      <PromptGenerator />
      <hr />
      <PromptLibrary />
    </main>
  );
}
