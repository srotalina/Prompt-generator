# Prompt Forge

A minimal, real BFF-architecture app: generate reusable prompt templates via
Claude, stream the response, save them to a personal library.

## Running it

```bash
# backend
cd backend
cp .env.example .env   # then paste your real Anthropic API key
npm install
npm run dev            # http://localhost:4000

# frontend (separate terminal)
cd frontend
npm install
npm run dev             # http://localhost:5173
```

## Architecture at a glance

```
Browser (React) --> Backend (Express, holds the API key) --> Anthropic API
                          |
                          v
                    data/prompts.json (swap for Postgres later)
```

## Concept map — where each idea lives

| Concept                                   | File                                  |
|--------------------------------------------|----------------------------------------|
| BFF pattern (key never in browser)         | backend/routes/generate.js            |
| Streaming (SSE) proxy                       | backend/routes/generate.js            |
| Repository pattern (storage seam)           | backend/db.js                         |
| Input validation at the trust boundary      | backend/routes/generate.js            |
| Middleware ordering, CORS, rate limiting    | backend/server.js                     |
| Single API client (no scattered fetch)      | frontend/src/api/client.js            |
| Streaming consumption on the client         | frontend/src/api/client.js            |
| Server state vs client state                | frontend/src/hooks/usePrompts.js      |
| Cache invalidation after mutation           | frontend/src/hooks/usePrompts.js      |
| Controlled inputs, functional state updates | frontend/src/components/PromptGenerator.jsx |
| Deriving UI from one state variable         | frontend/src/components/PromptGenerator.jsx |
| Container vs presentational components      | PromptLibrary.jsx vs PromptCard.jsx   |
| Loading/error/success discipline            | frontend/src/components/PromptLibrary.jsx |
| Composition root, provider placement        | App.jsx, main.jsx                     |

## What to deliberately try breaking (for learning)

1. Remove the CORS origin restriction in server.js and think through what
   that opens up.
2. Remove `queryClient.invalidateQueries` from a mutation and see the
   library silently go stale after a save.
3. Change `setOutput(prev => prev + chunk)` to `setOutput(output + chunk)`
   and watch characters go missing during fast streaming — this is the
   stale-closure bug made visible.
4. Point two browser tabs at the same library and delete a prompt in one —
   confirms why server state can't just be `useState`.
