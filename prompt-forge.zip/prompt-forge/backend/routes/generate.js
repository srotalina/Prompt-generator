// routes/generate.js
//
// CONCEPT 1: Backend-for-Frontend (BFF).
// This route is the ONLY place in the whole system that holds the
// Anthropic API key (it reads it from process.env, never from the client).
// The browser calls THIS endpoint; this endpoint calls Anthropic.
// If someone opens dev tools on the deployed frontend, all they ever see
// is a request to /api/generate — no key, no way to extract one.
//
// CONCEPT 2: Streaming pass-through.
// Claude's API can stream tokens back as Server-Sent Events (SSE) so the
// UI can render text as it arrives, like a "typing" effect, instead of
// waiting for the whole response then dumping it on screen. We don't have
// to buffer the whole Anthropic response and re-send it — we can pipe
// each chunk straight through as it arrives. This is the same pattern
// you'd reach for with any slow upstream service, not just LLMs.

import { Router } from "express";

const router = Router();

router.post("/generate", async (req, res) => {
  const { topic, category } = req.body;

  // CONCEPT 3: Never trust client input.
  // Validate here, not just in the frontend form. The frontend validation
  // is for UX (instant feedback); this validation is for safety — a
  // malicious or buggy client could hit this endpoint directly, bypassing
  // your React form entirely.
  if (!topic || typeof topic !== "string" || topic.trim().length === 0) {
    return res.status(400).json({ error: "topic is required" });
  }

  const systemPrompt = `You write high-quality, reusable prompt templates for
Claude. Given a topic and category, output ONE prompt template: clear,
specific, with placeholders in [brackets] where the user should fill in
their own details. Output only the prompt text — no preamble, no markdown
headers, no explanation.`;

  try {
    const anthropicResponse = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 500,
        system: systemPrompt,
        stream: true, // ask Anthropic for an SSE stream
        messages: [
          {
            role: "user",
            content: `Category: ${category || "general"}\nTopic: ${topic}`,
          },
        ],
      }),
    });

    if (!anthropicResponse.ok || !anthropicResponse.body) {
      const errText = await anthropicResponse.text();
      console.error("Anthropic error:", errText);
      return res.status(502).json({ error: "Upstream generation failed" });
    }

    // CONCEPT 4: Setting up our OWN SSE stream to the browser.
    // These headers tell the browser "don't buffer this, keep the
    // connection open, I'll send you events one at a time."
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const reader = anthropicResponse.body.getReader();
    const decoder = new TextDecoder();

    // CONCEPT 5: Re-shaping the upstream stream instead of raw piping.
    // Anthropic's SSE payload has its own event structure (message_start,
    // content_block_delta, message_stop, etc). Piping it raw would leak
    // Anthropic's wire format to our frontend and couple our UI to
    // Anthropic's API shape. Instead we parse each chunk and re-emit a
    // MINIMAL event our own frontend understands: just { text } deltas.
    // This is the same reason the BFF pattern exists at the JSON level —
    // here we're doing it at the streaming-protocol level too.
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split("\n").filter((l) => l.startsWith("data:"));

      for (const line of lines) {
        const jsonStr = line.replace("data:", "").trim();
        if (!jsonStr) continue;
        try {
          const event = JSON.parse(jsonStr);
          if (event.type === "content_block_delta" && event.delta?.text) {
            res.write(`data: ${JSON.stringify({ text: event.delta.text })}\n\n`);
          }
        } catch {
          // Ignore lines that aren't valid JSON (keep-alive pings etc).
        }
      }
    }

    res.write("data: [DONE]\n\n");
    res.end();
  } catch (err) {
    console.error(err);
    // If headers are already sent (streaming started), we can't send a
    // fresh JSON error — this guard avoids a crash from double-responding.
    if (!res.headersSent) {
      res.status(500).json({ error: "Internal error" });
    } else {
      res.end();
    }
  }
});

export default router;
