// routes/prompts.js
//
// CONCEPT: Thin controller layer.
// These handlers do almost nothing themselves — they just translate an
// HTTP verb into a call on db.js and shape the response. Business logic
// (if this app ever had any — e.g. "max 100 saved prompts per user")
// belongs in a service layer between this and db.js. We don't have real
// business logic yet, so we don't build that layer yet either — adding it
// now would be speculative complexity with no current payoff.

import { Router } from "express";
import { getAllPrompts, savePrompt, deletePrompt } from "../db.js";

const router = Router();

// GET /api/prompts — list the library
router.get("/prompts", async (_req, res) => {
  const prompts = await getAllPrompts();
  res.json(prompts);
});

// POST /api/prompts — save a generated (or hand-written) prompt
router.post("/prompts", async (req, res) => {
  const { title, body, category } = req.body;
  if (!body || typeof body !== "string") {
    return res.status(400).json({ error: "body is required" });
  }
  const record = await savePrompt({
    title: title || "Untitled prompt",
    body,
    category: category || "general",
  });
  res.status(201).json(record);
});

// DELETE /api/prompts/:id
router.delete("/prompts/:id", async (req, res) => {
  const removed = await deletePrompt(req.params.id);
  if (!removed) return res.status(404).json({ error: "Not found" });
  res.status(204).send();
});

export default router;
