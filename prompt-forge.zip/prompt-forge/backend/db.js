// db.js
//
// CONCEPT: Repository pattern.
// Every other file (routes) talks to "the data layer" through these three
// functions — getAll, save, remove — and never touches the storage detail
// directly. Today storage is a JSON file. Tomorrow it's Postgres/Supabase.
// Because routes/prompts.js only calls these functions, swapping the
// storage engine later means rewriting THIS file only — nothing upstream
// changes. That's the whole point of a repository layer: it's a seam you
// deliberately design in, so a real architectural decision (which DB) can
// be deferred without penalty.

import { readFile, writeFile } from "fs/promises";
import { existsSync } from "fs";

const DB_PATH = new URL("./data/prompts.json", import.meta.url);

async function ensureFile() {
  if (!existsSync(DB_PATH)) {
    await writeFile(DB_PATH, JSON.stringify([], null, 2));
  }
}

export async function getAllPrompts() {
  await ensureFile();
  const raw = await readFile(DB_PATH, "utf-8");
  return JSON.parse(raw);
}

export async function savePrompt(prompt) {
  const all = await getAllPrompts();
  const record = {
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    ...prompt,
  };
  all.unshift(record); // newest first
  await writeFile(DB_PATH, JSON.stringify(all, null, 2));
  return record;
}

export async function deletePrompt(id) {
  const all = await getAllPrompts();
  const filtered = all.filter((p) => p.id !== id);
  await writeFile(DB_PATH, JSON.stringify(filtered, null, 2));
  return filtered.length !== all.length; // true if something was removed
}
