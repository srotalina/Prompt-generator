// server.js
//
// This file's only job is composition: load config, attach middleware in
// the right order, mount routes, start listening. No business logic lives
// here — that's a smell you'd flag in review ("why is there a database
// query inside server.js?").

import "dotenv/config";
import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";

import generateRoute from "./routes/generate.js";
import promptsRoute from "./routes/prompts.js";

const app = express();
const PORT = process.env.PORT || 4000;

// CONCEPT: Middleware order matters.
// Express runs middleware top-to-bottom for every request. CORS and
// rate-limiting need to run BEFORE your routes, or a blocked/limited
// request would still reach your business logic before being rejected.

// CORS: only your known frontend origin may call this API.
// Using "*" here would mean ANY website could call your backend and burn
// your Anthropic quota — a real production incident, not a theoretical one.
app.use(
  cors({
    origin: process.env.ALLOWED_ORIGIN || "http://localhost:5173",
  })
);

app.use(express.json());

// CONCEPT: Rate limiting.
// This protects two things at once: your Anthropic billing (each call
// costs money) and basic abuse resistance. 20 requests per 15 minutes per
// IP is deliberately strict for a personal project — tune it up if it
// gets in your way while building.
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use("/api", limiter);

app.use("/api", generateRoute);
app.use("/api", promptsRoute);

app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});
